package com.example.harshi.capturephoto;

/**
 * Created by harshi on 16/02/17.
 */

public class Camera {
}
